/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author user
 */
public class p01_introduce {
    public static void main(String[] args) {
        System.out.println("Java training");
    }
}
