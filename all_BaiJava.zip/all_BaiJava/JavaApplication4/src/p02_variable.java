/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author user
 */
public class p02_variable {
//    public static void main(String[] args) {
//        int age = 20, year = 2015;
//        char name = 'n';
//        
//        System.out.println("age:" + age);
//        System.out.println (year);
//        System.out.println("name: " + name);
//         
//    }
    public static void main(String[] args) {
        int number = 20;
        System.out.println("Start = " + number);
    }
}
